﻿using System;
using System.Collections.Generic;
using System.Threading;


namespace NuPogodiAutoplay
{
    class Program
    {
        protected static int origRow;
        protected static int origCol;

        protected static void WriteAt(char s, int x, int y)
        {
            //try
            //{
            Console.SetCursorPosition(origCol + x, origRow + y);
            Console.Write(s);
            //}
            //catch (ArgumentOutOfRangeException e)
            //{
            //    Console.Clear();
            //    Console.WriteLine(e.Message);
            //}
        }
        static void Main()
        {
            char charEgg00 = ' ';
            char charEgg01 = ' ';
            char charEgg02 = ' ';
            char charEgg03 = ' ';
            char charEgg04 = ' ';
            char charEgg10 = ' ';
            char charEgg11 = ' ';
            char charEgg12 = ' ';
            char charEgg13 = ' ';
            char charEgg14 = ' ';
            char charEgg20 = ' ';
            char charEgg21 = ' ';
            char charEgg22 = ' ';
            char charEgg23 = ' ';
            char charEgg24 = ' ';
            char charEgg30 = ' ';
            char charEgg31 = ' ';
            char charEgg32 = ' ';
            char charEgg33 = ' ';
            char charEgg34 = ' ';

            int tempTime = 0;
            int tempState = 10;
            bool autoplay = true;
            int x = 0;

            //char start = Console.ReadKey().KeyChar;
            string str = @"
 _________________________________________________________________________
|                                                                         |
|      ^           |_| \/                                                 |
|     / \___       |_| /_   _  _                                          |
|    / _ \  |/|    | | | | |  | |  |\   | |                               |
|   / / \ \ | |    | | |_| |  |_| _|_|_ |/|                               |
|  / /   \ \|\|                                                           |
| / /     \ \       Press ENTER for start                                 |
|/_/       \_\                                                            |
| >\_/0>                                                           <0\_/< |
|  /_\                                                               /_\  |
|______                                                             ______|
|      \                                                           /      |
|       \                                                         /       |
| >\_/0> \                                                       / <0\_/< |
|  /_\    \                                                     /    /_\  |
|______    \                                                   /    ______|
|      \                                                           /      |
|       \                                                         /       |
|        \                                                       /        |
|         \                                                     /         |
|          \                                                   /          |
|                                                                         |
|                                                                         |
|                                                                         |
|                                                                         |
|                                                                         |
|                                                                         |
|                                                                         |
|                                                                         |
|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~|";

            char[,] time1 = {
                {' ',' ','#',' ',' '},
                {' ','#','#',' ',' '},
                {' ',' ','#',' ',' '},
                {' ',' ','#',' ',' '},
                {'#','#','#','#','#'}
                           };

            char[,] time2 = {
                {'#','#','#','#','#'},
                {'#',' ',' ',' ','#'},
                {' ',' ','#','#','#'},
                {'#','#',' ',' ',' '},
                {'#','#','#','#','#'}
                           };
            char[,] time3 = {
                {'#','#','#','#','#'},
                {'#',' ',' ',' ','#'},
                {' ',' ','#','#','#'},
                {'#',' ',' ',' ','#'},
                {'#','#','#','#','#'}
                           };

            char[,] time4 = {
                {'#',' ',' ',' ','#'},
                {'#',' ',' ',' ','#'},
                {'#','#','#','#','#'},
                {' ',' ',' ',' ','#'},
                {' ',' ',' ',' ','#'}
                           };

            char[,] time5 = {
                {'#','#','#','#','#'},
                {'#',' ',' ',' ',' '},
                {'#','#','#','#','#'},
                {' ',' ',' ',' ','#'},
                {'#','#','#','#','#'}
                           };

            char[,] time6 = {
                {'#','#','#','#','#'},
                {'#',' ',' ',' ',' '},
                {'#','#','#','#','#'},
                {'#',' ',' ',' ','#'},
                {'#','#','#','#','#'}
                           };

            char[,] time7 = {
                {'#','#','#','#','#'},
                {'#',' ',' ',' ','#'},
                {' ',' ',' ',' ','#'},
                {' ',' ',' ',' ','#'},
                {' ',' ',' ',' ','#'}
                           };

            char[,] time8 = {
                {'#','#','#','#','#'},
                {'#',' ',' ',' ','#'},
                {'#','#','#','#','#'},
                {'#',' ',' ',' ','#'},
                {'#','#','#','#','#'}
                           };

            char[,] time9 = {
                {'#','#','#','#','#'},
                {'#',' ',' ',' ','#'},
                {'#','#','#','#','#'},
                {' ',' ',' ',' ','#'},
                {'#','#','#','#','#'}
                           };

            char[,] time0 = {
                {'#','#','#','#','#'},
                {'#',' ',' ',' ','#'},
                {'#',' ',' ',' ','#'},
                {'#',' ',' ',' ','#'},
                {'#','#','#','#','#'}
                           };
            char[,] wolfLeft = {
                {' ',' ',' ',' ',' ',' ',' ',' ','|','\\',' ',' ',' ',' ',' ',' ',' ',' '},
                {' ',' ',' ',' ','_','.','/','^','(',' ',')',' ',' ',' ',' ',' ',' ',' '},
                {' ',' ',' ',' ','_',')','(',' ','_','_',')',')',' ',' ',' ',' ',' ',' '},
                {' ',' ',' ','O','_','_','@','@',' ',')',' ','|',')',' ',' ',' ',' ',' '},
                {' ',' ',' ','(','_','_',' ',' ',' ',' ','|',' ',')',' ',' ',' ',' ',' '},
                {' ',' ',' ',' ','_','/','_','_',' ',' ','_',')',' ',' ',' ',' ',' ',' '},
                {' ',' ',' ',' ',' ',' ',' ','|',' ','|','_',' ',' ',' ',' ',' ',' ',' '},
                {' ',' ',' ',' ',' ',' ','/','(','_',')',' ','|',' ',' ',' ',' ',' ',' '},
                {' ',' ',' ',' ',' ','|',' ',' ',' ',' ',' ','|',' ',' ',' ',' ',' ',' '},
                {' ',' ',' ',' ','|',' ',' ',' ',' ','_','/','_','_',' ',' ',' ',' ',' '},
                {' ',' ',' ',' ',' ','|','_','-','-','^',' ','(',' ','\\',' ',' ',' ',' '},
                {' ',' ',' ','_','/','*',' ',' ',' ',' ','*','|',' ','/',' ',' ',' ',' '},
                {' ',' ',' ','\\','\\',' ',' ','*','_','_','/','|',' ','|',' ',' ',' ',' '},
                {' ',' ',' ','|','\\','\\','_','/',' ',' ',' ','|',' ','|','_','_','_',' '},
                {' ',' ',' ','\\',' ','\\',' ',' ',' ',' ',' ','|','_','_','_','_','(',')'},
                {' ','_','_','_','\\','_','\\',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
                {'(',')','_','_','_','_','/',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '}
                          };
            char[,] basketLeftUp = {
                {' ',' ',' ',' ','_','_','_','_',' '},
                {' ',' ',' ','(','(',' ','\\',' ','\\'},
                {' ',' ',' ','/',' ','(',' ','\\',' '},
                {'_','_','(','_','_','_',')','_','\\'},
                {'\\',' ',' ',' ',' ',' ',' ',' ','/'},
                {' ','\\','_','_','_','_','_','/',' '},
                               };
            char[,] basketLeftDown = {
                {' ',' ',' ',' ','_','_','_','_','_'},
                {' ',' ',' ','(','(','_','_','_','_'},
                {' ',' ',' ','/',' ','(',' ',' ',' '},
                {'_','_','(','_','_','_',')','_','_'},
                {'\\',' ',' ',' ',' ',' ',' ',' ','/'},
                {' ','\\','_','_','_','_','_','/',' '},
                               };
            char[,] wolfRight = {
                {' ',' ',' ',' ',' ',' ',' ',' ','/','|',' ',' ',' ',' ',' ',' ',' ',' '},
                {' ',' ',' ',' ',' ',' ',' ','(',' ',')','^','\\','.','_',' ',' ',' ',' '},
                {' ',' ',' ',' ',' ',' ','(','(',' ','_','_',')','(','_',' ',' ',' ',' '},
                {' ',' ',' ',' ',' ','(','|',' ','(',' ','@','@','_','_','O',' ',' ',' '},
                {' ',' ',' ',' ',' ','(',' ','|',' ',' ',' ',' ','_','_',')',' ',' ',' '},
                {' ',' ',' ',' ',' ',' ','(','_',' ',' ','_','_','\\','_',' ',' ',' ',' '},
                {' ',' ',' ',' ',' ',' ',' ',' ','_','|',' ','|',' ',' ',' ',' ',' ',' '},
                {' ',' ',' ',' ',' ',' ',' ','|',' ','(','_',')','\\',' ',' ',' ',' ',' '},
                {' ',' ',' ',' ',' ',' ',' ','|',' ',' ',' ',' ',' ','|',' ','_',' ',' '},
                {' ',' ',' ',' ',' ','_','_','\\','_',' ',' ',' ',' ',' ','|',' ',' ',' '},
                {' ',' ',' ',' ','/',' ',')',' ',' ','^','-','-','_','|',' ',' ',' ',' '},
                {' ',' ',' ',' ','\\',' ','|','*',' ',' ',' ',' ',' ','*','\\',' ',' ',' '},
                {' ',' ',' ',' ','|',' ','|','\\','_','_','*',' ',' ',' ','/',' ',' ',' '},
                {' ','_','_','_','|',' ','|',' ',' ',' ','\\','_','/','/','|',' ',' ',' '},
                {'(',')','_','_','_','_','|',' ',' ',' ',' ',' ','/',' ','/',' ',' ',' '},
                {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','/','_','/','_','_','_',' '},
                {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','\\','_','_','_','_','(',')'}
                                 };
            char[,] basketUpRight = {
                {' ',' ','_','_','_',' ',' ',' ',' '},
                {' ','/',' ','/',')',')',' ',' ',' '},
                {'/',' ','/',')',' ','\\',' ',' ',' '},
                {'_','/','(','_','_','_',')','_','_'},
                {'\\',' ',' ',' ',' ',' ',' ',' ','/'},
                {' ','\\','_','_','_','_','_','/',' '},
                                    };
            char[,] basketDownRight = {
                {'_','_','_','_','_',' ',' ',' ',' '},
                {'_','_','_','_',')',')',' ',' ',' '},
                {' ',' ',' ',')',' ','\\',' ',' ',' '},
                {'_','_','(','_','_','_',')','_','_'},
                {'\\',' ',' ',' ',' ',' ',' ',' ','/'},
                {' ','\\','_','_','_','_','_','/',' '},
                                    };

            char[] charArray = str.ToCharArray();
            for (int i = 0; i < charArray.Length; i++)
            {
                if (i > 2250)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write(charArray[i]);
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write(charArray[i]);
                }
            }
            while (autoplay)
            {
                if (tempTime == 800)
                {

                    //get sistem time
                    string time = DateTime.Now.ToString("HH:mm");
                    char[] timeArray = time.ToCharArray();

                    for (int i = 0; i <= 6; i++)
                    {
                        if (i == 0)
                        {
                            x = 194;

                            if (timeArray[i] == '1')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time1[j, k], k + 45, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '2')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time2[j, k], k + 45, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '0')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time0[j, k], k + 45, j + 3);
                                    }
                                }
                            }
                        }

                        if (i == 1)
                        {
                            if (timeArray[i] == '1')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time1[j, k], k + 51, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '2')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time2[j, k], k + 51, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '3')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time3[j, k], k + 51, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '4')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time4[j, k], k + 51, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '5')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time5[j, k], k + 51, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '6')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time6[j, k], k + 51, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '7')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time7[j, k], k + 51, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '8')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time8[j, k], k + 51, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '9')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time9[j, k], k + 51, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '0')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time0[j, k], k + 51, j + 3);
                                    }
                                }
                            }
                        }

                        WriteAt('#',57, 4);
                        WriteAt('#',57, 6);

                        //set minutes
                        if (i == 3)
                        {
                            if (timeArray[i] == '1')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time1[j, k], k + 60, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '2')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time2[j, k], k + 60, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '3')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time3[j, k], k + 60, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '4')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time4[j, k], k + 60, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '5')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time5[j, k], k + 60, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '6')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time6[j, k], k + 60, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '7')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time7[j, k], k + 60, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '8')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time8[j, k], k + 60, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '9')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time9[j, k], k + 60, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '0')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time0[j, k], k + 60, j + 3);
                                    }
                                }
                            }
                        }
                        if (i == 4)
                        {
                            if (timeArray[i] == '1')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time1[j, k], k + 66, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '2')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time2[j, k], k + 66, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '3')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time3[j, k], k + 66, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '4')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time4[j, k], k + 66, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '5')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time5[j, k], k + 66, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '6')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time6[j, k], k + 66, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '7')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time7[j, k], k + 66, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '8')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time8[j, k], k + 66, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '9')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time9[j, k], k + 66, j + 3);
                                    }
                                }
                            }
                            if (timeArray[i] == '0')
                            {
                                for (int j = 0; j < 5; j++)
                                {
                                    for (int k = 0; k < 5; k++)
                                    {
                                        WriteAt(time0[j, k], k + 66, j + 3);
                                    }
                                }
                            }
                        }
                    }
                    
                    Random random = new Random();
                    int randomNumber = random.Next(0, 6);
                    Random wolfRandom = new Random();
                    int wolfRandomNumber = wolfRandom.Next(0, 4);

                    charEgg04 = charEgg03; //5
                    charEgg03 = charEgg02; //4
                    charEgg02 = charEgg01; //3
                    charEgg01 = charEgg00; //2
                    charEgg00 = ' ';
                    charEgg14 = charEgg13; //5
                    charEgg13 = charEgg12; //4
                    charEgg12 = charEgg11; //3
                    charEgg11 = charEgg10; //2
                    charEgg10 = ' ';
                    charEgg24 = charEgg23; //5
                    charEgg23 = charEgg22; //4
                    charEgg22 = charEgg21; //3
                    charEgg21 = charEgg20; //2
                    charEgg20 = ' ';
                    charEgg34 = charEgg33; //5
                    charEgg33 = charEgg32; //4
                    charEgg32 = charEgg31; //3
                    charEgg31 = charEgg30; //2
                    charEgg00 = ' ';
                    char upLeft = (randomNumber == 0) ? charEgg00 = '0' : charEgg00 = ' ';
                    char upRigth = (randomNumber == 1) ? charEgg10 = '0' : charEgg10 = ' ';
                    char downLeft = (randomNumber == 2) ? charEgg20 = '0' : charEgg20 = ' ';
                    char downRigth = (randomNumber == 3) ? charEgg30 = '0' : charEgg30 = ' ';

                    WriteAt(charEgg00, 8, 13);
                    WriteAt(charEgg01, 9, 14);
                    WriteAt(charEgg02, 10, 15);
                    WriteAt(charEgg03, 11, 16);
                    WriteAt(charEgg04, 12, 17);

                    WriteAt(charEgg10, 66, 13);
                    WriteAt(charEgg11, 65, 14);
                    WriteAt(charEgg12, 64, 15);
                    WriteAt(charEgg13, 63, 16);
                    WriteAt(charEgg14, 62, 17);

                    WriteAt(charEgg20, 8, 18);
                    WriteAt(charEgg21, 9, 19);
                    WriteAt(charEgg22, 10, 20);
                    WriteAt(charEgg23, 11, 21);
                    WriteAt(charEgg24, 12, 22);

                    WriteAt(charEgg30, 66, 18);
                    WriteAt(charEgg31, 65, 19);
                    WriteAt(charEgg32, 64, 20);
                    WriteAt(charEgg33, 63, 21);
                    WriteAt(charEgg34, 62, 22);

                    Console.ForegroundColor = ConsoleColor.Yellow;
                    if (wolfRandomNumber == 0 || wolfRandomNumber == 1)
                    {
                        if ((tempState != 0) && (tempState != 1))
                        {
                            for (int i = 14; i < 31; i++)
                            {
                                for (int j = 19; j < 37; j++)
                                {
                                    WriteAt(wolfLeft[i - 14, j - 19], j, i);
                                }
                            }
                        }
                    }
                    else
                    {
                        for (int i = 14; i < 31; i++)
                        {
                            for (int j = 19; j < 37; j++)
                            {
                                WriteAt(' ', j, i);
                            }
                        }
                    }
                    if (wolfRandomNumber == 2 || wolfRandomNumber == 3)
                    {
                        if ((tempState != 2) && (tempState != 3))
                        {
                            for (int i = 14; i < 31; i++)
                            {
                                for (int j = 38; j < 56; j++)
                                {
                                    WriteAt(wolfRight[i - 14, j - 38], j, i);
                                }
                            }
                        }
                    }
                    else
                    {
                        for (int i = 14; i < 31; i++)
                        {
                            for (int j = 38; j < 56; j++)
                            {
                                WriteAt(' ', j, i);
                            }
                        }
                    }

                    //bsket up left
                    if (wolfRandomNumber == 0)
                    {
                        if (tempState != 0)
                        {
                            for (int i = 16; i < 22; i++)
                            {
                                for (int j = 13; j < 22; j++)
                                {
                                    WriteAt(basketLeftUp[i - 16, j - 13], j, i);
                                    tempState = 0;
                                }
                            }
                        }
                    }
                    else
                    {
                        for (int i = 16; i < 22; i++)
                        {
                            for (int j = 13; j < 22; j++)
                            {
                                WriteAt(' ', j, i);
                            }
                        }
                    }
                    //basket down left
                    if (wolfRandomNumber == 1)
                    {
                        if (tempState != 1)
                        {
                            for (int i = 22; i < 28; i++)
                            {
                                for (int j = 13; j < 22; j++)
                                {
                                    WriteAt(basketLeftDown[i - 22, j - 13], j, i);
                                    tempState = 1;
                                }
                            }
                        }
                    }
                    else
                    {
                        for (int i = 22; i < 28; i++)
                        {
                            for (int j = 13; j < 22; j++)
                            {
                                WriteAt(' ', j, i);
                            }
                        }
                    }

                    //basket up right
                    if (wolfRandomNumber == 2)
                    {
                        if (tempState != 2)
                        {
                            for (int i = 16; i < 22; i++)
                            {
                                for (int j = 53; j < 62; j++)
                                {
                                    WriteAt(basketUpRight[i - 16, j - 53], j, i);
                                    tempState = 2;
                                }
                            }
                        }
                    }
                    else
                    {
                        for (int i = 16; i < 22; i++)
                        {
                            for (int j = 53; j < 62; j++)
                            {
                                WriteAt(' ', j, i);
                            }
                        }
                    }
                    //basket down right
                    if (wolfRandomNumber == 3)
                    {
                        if (tempState != 3)
                        {
                            for (int i = 22; i < 28; i++)
                            {
                                for (int j = 53; j < 62; j++)
                                {
                                    WriteAt(basketDownRight[i - 22, j - 53], j, i);
                                    tempState = 3;
                                }
                            }
                        }
                    }
                    else
                    {
                        for (int i = 22; i < 28; i++)
                        {
                            for (int j = 53; j < 62; j++)
                            {
                                WriteAt(' ', j, i);
                            }
                        }
                    }
                    Console.ForegroundColor = ConsoleColor.Green;
                    WriteAt(' ', 0, 32);
                    tempTime = 0;
                }
                Thread.Sleep(10);
                tempTime += 10;
            }
        }
    }
}